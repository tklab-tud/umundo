#include "umundo/connection/zeromq/ZeroMQNode.h"

#include "umundo/config.h"

#if defined UNIX || defined IOS || defined IOSSIM
#include <arpa/inet.h> // htons
#include <string.h> // strlen, memcpy
#include <stdio.h> // snprintf
#endif

#include <boost/lexical_cast.hpp>

#include "umundo/common/Message.h"
#include "umundo/discovery/Discovery.h"
#include "umundo/discovery/NodeQuery.h"
#include "umundo/connection/zeromq/ZeroMQPublisher.h"
#include "umundo/connection/zeromq/ZeroMQSubscriber.h"

namespace umundo {

ZeroMQNode::~ZeroMQNode() {
  Discovery::unbrowse(_nodeQuery);
		
	set<shared_ptr<ZeroMQPublisher> >::iterator pubIter = _localPubs.begin();
	set<shared_ptr<ZeroMQSubscriber> >::iterator subIter = _localSubs.begin();
	_mutex.lock();
	do {
		removeSubscriber(*subIter);
	} while (subIter != _localSubs.end());
	do {
		removePublisher(*pubIter);
	} while (pubIter != _localPubs.end());
	_mutex.unlock();

	stop();
	join();

	while(zmq_close(_pubSocket) != 0) {
	  LOG_WARN("zmq_close: %s - retrying", zmq_strerror(errno));
	  Thread::sleepMs(50);
	}  
}

ZeroMQNode::ZeroMQNode() {
	DEBUG_CTOR("ZeroMQNode");
}

shared_ptr<Implementation> ZeroMQNode::create() {
	return shared_ptr<ZeroMQNode>(new ZeroMQNode());
}

void ZeroMQNode::destroy() {
	delete(this);
}

void* ZeroMQNode::getZeroMQContext() {
	if (_zmqContext == NULL) {
		(_zmqContext = zmq_init(1)) || LOG_ERR("zmq_init: %s",zmq_strerror(errno));
	}
	return _zmqContext;
}
void* ZeroMQNode::_zmqContext = NULL;

void ZeroMQNode::init(shared_ptr<Configuration> config) {
	_config = boost::static_pointer_cast<NodeConfig>(config);
	_transport = "tcp";

	_nodeQuery = shared_ptr<NodeQuery>(new NodeQuery(_domain, this));
	(_pubSocket = zmq_socket(getZeroMQContext(), ZMQ_XPUB))  || LOG_ERR("zmq_socket: %s",zmq_strerror(errno));

	// start with 4242 and work your way up until we find a free port
	int port = 4242;

	std::stringstream ss;
	ss << _transport << "://*:" << port;
	LOG_DEBUG("trying to bind at %s", ss.str().c_str());

	while(zmq_bind(_pubSocket, ss.str().c_str()) == -1) {
		switch(errno) {
		case EADDRINUSE:
			port++;
			ss.clear();        // clear error bits
			ss.str(string());  // reset string
			ss << _transport << "://*:" << port;
			break;
		default:
			LOG_WARN("zmq_bind: %s",zmq_strerror(errno));
			Thread::sleepMs(100);
		}
	}
	_port = port;
	LOG_INFO("Node %s listening as %s", SHORT_UUID(_uuid).c_str(), ss.str().c_str());
	Discovery::browse(_nodeQuery);
	start();
}

void ZeroMQNode::run() {

	zmq_pollitem_t item;
	item.socket = _pubSocket;
	item.events = ZMQ_POLLIN;

	do {
    // process zeromq subscription requests
		zmq_msg_t message;
		zmq_msg_init(&message) && LOG_WARN("zmq_msg_init: %s",zmq_strerror(errno));
		
		int rv = 0;

		for (;;) {
			_mutex.lock();
			rv = zmq_poll(&item, 1, 0);
			if (!isStarted()) {
				_mutex.unlock();
				LOG_ERR("QUITTING!");
				return;
			}
			if (rv > 0)
				break;
			_mutex.unlock();
			if (rv != 0) {
				LOG_WARN("zmq_poll: %s",zmq_strerror(errno));
			}
			Thread::sleepMs(50);
		}
		zmq_recvmsg(_pubSocket, &message, 0) >= 0 || LOG_WARN("zmq_recvmsg: %s",zmq_strerror(errno));
		_mutex.unlock();
		size_t msgSize = zmq_msg_size(&message);
    if (msgSize > 0) {
      _mutex.lock();
      char* data = (char*)zmq_msg_data(&message);
      bool subscription = (data[0] == 0x1);
      char* channelName = data+1;

			LOG_INFO("%s has %s request for channel %s", 
				SHORT_UUID(_uuid).c_str(), 
				(subscription ? "subscription" : "unsubscription"),
				channelName);

      if (_subscriptions.find(channelName) == _subscriptions.end())
        _subscriptions[channelName] = 0;
      
      if (!subscription && _subscriptions[channelName] < 1) {
        LOG_WARN("Unsubscription request for unsubscribed channel %s", channelName);
        _mutex.unlock();
        zmq_msg_close(&message) && LOG_WARN("zmq_msg_close: %s",zmq_strerror(errno));    
        continue;
      }
      
      if (subscription) {
        _subscriptions[channelName] = _subscriptions[channelName] + 1;
      } else {
        _subscriptions[channelName] = _subscriptions[channelName] - 1;
      }

      set<shared_ptr<ZeroMQPublisher> >::iterator pubIter;
      for (pubIter = _localPubs.begin(); pubIter != _localPubs.end(); pubIter++) {
        if ((*pubIter)->getChannelName().compare(channelName) == 0) {
          if (subscription) {
            (*pubIter)->addedSubscriber();
          } else {
            (*pubIter)->removedSubscriber();
          }
        }
      }
      _mutex.unlock();
    }
    zmq_msg_close(&message) && LOG_WARN("zmq_msg_close: %s",zmq_strerror(errno));    

	} while(isStarted());
}

void ZeroMQNode::added(shared_ptr<NodeStub> node) {
	assert(node->getUUID().length() == 36);
	if (node->getUUID().compare(_uuid) != 0) {
		LOG_INFO("%s added %s at %s", SHORT_UUID(_uuid).c_str(), SHORT_UUID(node->getUUID()).c_str(), node->getIP().c_str());

		// we found ourselves a remote node, lets get some privacy
		_mutex.lock();
		assert(_nodes.find(node->getUUID()) == _nodes.end());
		_nodes[node->getUUID()] = node;
		set<shared_ptr<ZeroMQSubscriber> >::iterator subIter;
		for (subIter = _localSubs.begin(); subIter != _localSubs.end(); subIter++) {
			(*subIter)->added(node);
		}

		_mutex.unlock();
	}
}

void ZeroMQNode::removed(shared_ptr<NodeStub> node) {
	assert(node->getUUID().length() == 36);
	if (node->getUUID().compare(_uuid) != 0) {
		LOG_INFO("%s removed %s", SHORT_UUID(_uuid).c_str(), SHORT_UUID(node->getUUID()).c_str());

		_mutex.lock();
		assert(_nodes.find(node->getUUID()) != _nodes.end());
		set<shared_ptr<ZeroMQSubscriber> >::iterator subIter;
		for (subIter = _localSubs.begin(); subIter != _localSubs.end(); subIter++) {
			(*subIter)->removed(node);
		}
		_nodes.erase(node->getUUID());
		_mutex.unlock();
	}
}

void ZeroMQNode::changed(shared_ptr<NodeStub> node) {
}

/**
 * Add a local subscriber.
 */
void ZeroMQNode::addSubscriber(shared_ptr<SubscriberImpl> sub) {
	shared_ptr<ZeroMQSubscriber> zSub = boost::static_pointer_cast<ZeroMQSubscriber>(sub);
	assert(zSub.get() != NULL);

	_mutex.lock();
	if (_localSubs.find(zSub) != _localSubs.end()) {
		LOG_WARN("Subscriber already added to node");
		_mutex.unlock();
	}
	_localSubs.insert(zSub);
	map<string, shared_ptr<NodeStub> >::const_iterator nodeIter;
	for (nodeIter = _nodes.begin(); nodeIter != _nodes.end(); nodeIter++) {
		zSub->added(nodeIter->second);
	}
	_mutex.unlock();
}

/**
 * Remove a local subscriber.
 */
void ZeroMQNode::removeSubscriber(shared_ptr<SubscriberImpl> sub) {
	shared_ptr<ZeroMQSubscriber> zSub = boost::static_pointer_cast<ZeroMQSubscriber>(sub);
	assert(zSub.get() == NULL);

	if (_localSubs.find(zSub) == _localSubs.end()) {
		LOG_WARN("Subscriber never added to node");
		_mutex.unlock();
	}
	map<string, shared_ptr<NodeStub> >::const_iterator nodeIter;
	for (nodeIter = _nodes.begin(); nodeIter != _nodes.end(); nodeIter++) {
		zSub->removed(nodeIter->second);
	}
	_localSubs.erase(zSub);
	
	_mutex.unlock();

}

void ZeroMQNode::addPublisher(shared_ptr<PublisherImpl> pub) {
	shared_ptr<ZeroMQPublisher> zPub = boost::static_pointer_cast<ZeroMQPublisher>(pub);
	assert(zPub.get() != NULL);

	_mutex.lock();
	// do we already now this publisher?
	if (_localPubs.find(zPub) != _localPubs.end()) {
		LOG_DEBUG("Publisher already added %s", zPub->getChannelName().c_str());
		_mutex.unlock();
		return;
	}
	zPub->added(shared_from_this());

  // notify of existing subscriptions
  if (_subscriptions.find(zPub->getChannelName()) != _subscriptions.end()) {
    int subscriptions = _subscriptions[zPub->getChannelName()];
    while(subscriptions > 0) {
      zPub->addedSubscriber();
      subscriptions--;
    }
  }
	_localPubs.insert(zPub);
	_mutex.unlock();
}

void ZeroMQNode::removePublisher(shared_ptr<PublisherImpl> pub) {
	shared_ptr<ZeroMQPublisher> zPub = boost::static_pointer_cast<ZeroMQPublisher>(pub);
	assert(zPub.get() == NULL);

	_mutex.lock();
	if (_localPubs.find(zPub) == _localPubs.end()) {
		LOG_DEBUG("Publisher never added %s", zPub->getChannelName().c_str());
		_mutex.unlock();
		return;
	}
  
  // remove existing subscriptions to this node
  if (_subscriptions.find(zPub->getChannelName()) != _subscriptions.end()) {
    int subscriptions = _subscriptions[zPub->getChannelName()];
    while(subscriptions > 0) {
      zPub->removedSubscriber();
      subscriptions--;
    }
  }
	zPub->removed(shared_from_this());
	_localPubs.erase(zPub);
	_mutex.unlock();

}

}
