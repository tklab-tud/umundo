#include "umundo/connection/zeromq/ZeroMQNode.h"

#include "umundo/connection/Publisher.h"
#include "umundo/common/Message.h"
#include "umundo/common/UUID.h"

// include order matters with MSVC ...
#include "umundo/connection/zeromq/ZeroMQSubscriber.h"

#include "umundo/config.h"
#if defined UNIX || defined IOS || defined IOSSIM
#include <stdio.h> // snprintf
#endif

namespace umundo {

shared_ptr<Implementation> ZeroMQSubscriber::create() {
	shared_ptr<Implementation> instance(new ZeroMQSubscriber());
	return instance;
}

void ZeroMQSubscriber::destroy() {
	delete(this);
}

ZeroMQSubscriber::ZeroMQSubscriber() {
	DEBUG_CTOR("ZeroMQSubscriber");
}

ZeroMQSubscriber::~ZeroMQSubscriber() {
	DEBUG_DTOR("ZeroMQSubscriber start");
  stop();
  join();
	zmq_close(_socket) && LOG_WARN("zmq_close: %s",zmq_strerror(errno));
	DEBUG_DTOR("ZeroMQSubscriber finished");
}

void ZeroMQSubscriber::init(shared_ptr<Configuration> config) {
	_config = boost::static_pointer_cast<SubscriberConfig>(config);
	_uuid = UUID::getUUID();

	void* ctx = ZeroMQNode::getZeroMQContext();
	(_socket = zmq_socket(ctx, ZMQ_SUB)) || LOG_WARN("zmq_socket: %s",zmq_strerror(errno));

  assert(_channelName.size() > 0);
	int hwm = NET_ZEROMQ_RCV_HWM;
	zmq_setsockopt(_socket, ZMQ_RCVHWM, &hwm, sizeof(hwm)) && LOG_WARN("zmq_setsockopt: %s",zmq_strerror(errno));
	zmq_setsockopt(_socket, ZMQ_SUBSCRIBE, _channelName.c_str(), _channelName.size()) && LOG_WARN("zmq_setsockopt: %s",zmq_strerror(errno));
	zmq_setsockopt(_socket, ZMQ_IDENTITY, _uuid.c_str(), _uuid.length()) && LOG_WARN("zmq_setsockopt: %s",zmq_strerror(errno));

	start();
}

void ZeroMQSubscriber::run() {
	int32_t more;
	size_t more_size = sizeof(more);

	zmq_pollitem_t item;
	item.socket = _socket;
	item.events = ZMQ_POLLIN;
	
	while(isStarted()) {
		// read whole envelope
		Message* msg = new Message();
		while (1) {
			zmq_msg_t message;
			zmq_msg_init(&message) && LOG_WARN("zmq_msg_init: %s",zmq_strerror(errno));

			int rv;
			while ((rv = zmq_poll(&item, 1, 50)) < 1) {
				if (!isStarted())
					return;
				if (rv != 0)
					LOG_WARN("zmq_poll: %s",zmq_strerror(errno));
			}
			zmq_recvmsg(_socket, &message, 0) >= 0 || LOG_WARN("zmq_recvmsg: %s",zmq_strerror(errno));
			size_t msgSize = zmq_msg_size(&message);
			LOG_DEBUG("Received %d bytes on %s", msgSize, _channelName.c_str());

      if (!isStarted()) {
				zmq_msg_close(&message) && LOG_WARN("zmq_msg_close: %s",zmq_strerror(errno));
        return;
      }
      
			// last message contains actual data
			zmq_getsockopt(_socket, ZMQ_RCVMORE, &more, &more_size) && LOG_WARN("zmq_getsockopt: %s",zmq_strerror(errno));

			if (more) {
				char* key = (char*)zmq_msg_data(&message);
				char* value = ((char*)zmq_msg_data(&message) + strlen(key) + 1);

				// is this the first message with the channelname?
				if (strlen(key) + 1 == msgSize &&
				        msg->getMeta().find(key) == msg->getMeta().end()) {
					msg->setMeta("channelName", key);
				} else {
					assert(strlen(key) + strlen(value) + 2 == msgSize);
					if (strlen(key) + strlen(value) + 2 != msgSize) {
						LOG_WARN("Received malformed message %d + %d + 2 != %d", strlen(key), strlen(value), msgSize);
						zmq_msg_close(&message) && LOG_WARN("zmq_msg_close: %s",zmq_strerror(errno));
						break;
					} else {
						msg->setMeta(key, value);
					}
				}
				zmq_msg_close(&message) && LOG_WARN("zmq_msg_close: %s",zmq_strerror(errno));
			} else {
				msg->setData(string((char*)zmq_msg_data(&message), msgSize));
				zmq_msg_close(&message) && LOG_WARN("zmq_msg_close: %s",zmq_strerror(errno));
				_receiver->receive(msg);
				break; // last message part
			}
		}
		delete(msg);

	}
}

void ZeroMQSubscriber::added(shared_ptr<NodeStub> node) {
  _mutex.lock();
	std::stringstream ss;
	ss << node->getTransport() << "://" << node->getIP() << ":" << node->getPort();
  LOG_INFO("%s connecting to %s at %s", _channelName.c_str(), SHORT_UUID(node->getUUID()).c_str(), ss.str().c_str());
	zmq_connect(_socket, ss.str().c_str()) && LOG_WARN("zmq_connect: %s",zmq_strerror(errno));
  _mutex.unlock();
}

void ZeroMQSubscriber::removed(shared_ptr<NodeStub> node) {
}

void ZeroMQSubscriber::changed(shared_ptr<NodeStub> node) {
	// never called
}


}