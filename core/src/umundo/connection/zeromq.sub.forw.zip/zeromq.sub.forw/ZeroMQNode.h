#ifndef ZEROMQDISPATCHER_H_XFMTSVLV
#define ZEROMQDISPATCHER_H_XFMTSVLV

#include <zmq.h>
#include <boost/enable_shared_from_this.hpp>

#include "umundo/common/Common.h"
#include "umundo/thread/Thread.h"
#include "umundo/common/ResultSet.h"
#include "umundo/common/Node.h"

/// Initialize a zeromq message with a given size
#define ZMQ_PREPARE(msg, size) \
zmq_msg_init(&msg) && LOG_WARN("zmq_msg_init: %s", zmq_strerror(errno)); \
zmq_msg_init_size (&msg, size) && LOG_WARN("zmq_msg_init_size: %s",zmq_strerror(errno));

/// Initialize a zeromq message with a given size and memcpy data
#define ZMQ_PREPARE_DATA(msg, data, size) \
zmq_msg_init(&msg) && LOG_WARN("zmq_msg_init: %s", zmq_strerror(errno)); \
zmq_msg_init_size (&msg, size) && LOG_WARN("zmq_msg_init_size: %s",zmq_strerror(errno)); \
memcpy(zmq_msg_data(&msg), data, size);

/// Initialize a zeromq message with a given null-terminated string
#define ZMQ_PREPARE_STRING(msg, data, size) \
zmq_msg_init(&msg) && LOG_WARN("zmq_msg_init: %s", zmq_strerror(errno)); \
zmq_msg_init_size (&msg, size + 1) && LOG_WARN("zmq_msg_init_size: %s",zmq_strerror(errno)); \
memcpy(zmq_msg_data(&msg), data, size + 1);

namespace umundo {

class ZeroMQPublisher;
class ZeroMQSubscriber;
class NodeQuery;

/**
 * Concrete node implementor for 0MQ (bridge pattern).
 */
class ZeroMQNode : public ResultSet<NodeStub>, public Thread, public NodeImpl, public boost::enable_shared_from_this<ZeroMQNode> {
public:
	virtual ~ZeroMQNode();

	/** @name Implementor */
	//@{
	shared_ptr<Implementation> create();
	void destroy();
	void init(shared_ptr<Configuration>);
	//@}

	/** @name Publish / Subscriber Maintenance */
	//@{
	void addSubscriber(shared_ptr<SubscriberImpl>);
	void removeSubscriber(shared_ptr<SubscriberImpl>);
	void addPublisher(shared_ptr<PublisherImpl>);
	void removePublisher(shared_ptr<PublisherImpl>);
	//@}

	/** @name Callbacks from Discovery */
	//@{
	void added(shared_ptr<NodeStub>);    ///< A node was added, connect to its router socket and list our publishers.
	void removed(shared_ptr<NodeStub>);  ///< A node was removed, notify local subscribers and clean up.
	void changed(shared_ptr<NodeStub>);  ///< Never happens.
	//@}

	void run(); ///< Thread

	static void* getZeroMQContext(); ///< single 0MQ context

protected:
	ZeroMQNode();

private:
	static void* _zmqContext; ///< global 0MQ context.

	Mutex _mutex;
	shared_ptr<NodeQuery> _nodeQuery; ///< the NodeQuery which we registered at the Discovery sub-system.

	void* _pubSocket;                                 ///< the single publisher socket for this node
	map<string, shared_ptr<NodeStub> > _nodes;        ///< UUIDs to NodeStub%s.
	set<shared_ptr<ZeroMQPublisher> > _localPubs;     ///< local publishers.
	set<shared_ptr<ZeroMQSubscriber> > _localSubs;    ///< Local subscribers.
	map<string, int> _subscriptions;                  ///< number of subscriptions for channels
	shared_ptr<NodeConfig> _config;

	friend std::ostream& operator<<(std::ostream&, const ZeroMQNode*);
	friend class ZeroMQPublisher;
	friend class Factory;
};

}

#endif /* end of include guard: ZEROMQDISPATCHER_H_XFMTSVLV */
