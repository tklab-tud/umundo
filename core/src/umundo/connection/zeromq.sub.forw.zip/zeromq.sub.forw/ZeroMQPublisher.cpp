#ifdef WIN32
#include <time.h>
#include <WinSock2.h>
#include <ws2tcpip.h>
#include <Windows.h>
#endif

#include "umundo/connection/zeromq/ZeroMQPublisher.h"

#include "umundo/connection/zeromq/ZeroMQNode.h"
#include "umundo/common/Message.h"
#include "umundo/common/UUID.h"

#include "umundo/config.h"
#if defined UNIX || defined IOS || defined IOSSIM
#include <string.h> // strlen, memcpy
#include <stdio.h> // snprintf
#endif

namespace umundo {

shared_ptr<Implementation> ZeroMQPublisher::create() {
	shared_ptr<Implementation> instance(new ZeroMQPublisher());
	return instance;
}

void ZeroMQPublisher::destroy() {
	delete(this);
}

void ZeroMQPublisher::init(shared_ptr<Configuration> config) {
	_uuid = UUID::getUUID();
	_config = boost::static_pointer_cast<PublisherConfig>(config);
	_transport = "tcp";
	_pubCount = 0;
}

ZeroMQPublisher::ZeroMQPublisher() {
}

ZeroMQPublisher::~ZeroMQPublisher() {
}

/**
 * Block until we have a given number of subscribers.
 */
int ZeroMQPublisher::waitForSubscribers(int count) {
	while (_pubCount < count) {
		_pubLock.wait();
		// give the connection a moment to establish
		Thread::sleepMs(100);
	}
	return _pubCount;
}

void ZeroMQPublisher::addedSubscriber() {
	_pubCount++;
	_pubLock.signal();
}

void ZeroMQPublisher::removedSubscriber() {
	_pubCount--;
	_pubLock.signal();
}

void ZeroMQPublisher::added(shared_ptr<ZeroMQNode> node) {
	_mutex.lock();
	if (_nodes.find(node) != _nodes.end()) {
		LOG_WARN("Publisher already added to given node");
		_mutex.unlock();
		return;
	}
	_nodes.insert(node);
	_mutex.unlock();
}

void ZeroMQPublisher::changed(shared_ptr<ZeroMQNode> node) {
}

void ZeroMQPublisher::removed(shared_ptr<ZeroMQNode> node) {
	_mutex.lock();
	if (_nodes.find(node) == _nodes.end()) {
		LOG_WARN("Publisher was never added to given node");
		_mutex.unlock();
		return;
	}
	_nodes.erase(node);
	_mutex.unlock();
}

/**
 * Send data on all pub sockets of nodes we have been added to.
 */
void ZeroMQPublisher::send(Message* msg) {
	_mutex.lock();

	set<shared_ptr<ZeroMQNode> >::iterator nodeIter;
	for (nodeIter = _nodes.begin(); nodeIter != _nodes.end(); nodeIter++) {
		(*nodeIter)->_mutex.lock();

		// topic name is first message in envelope
		zmq_msg_t channelEnvlp;
		ZMQ_PREPARE_STRING(channelEnvlp, _channelName.c_str(), _channelName.size());
		zmq_sendmsg((*nodeIter)->_pubSocket, &channelEnvlp, ZMQ_SNDMORE) >= 0 || LOG_WARN("zmq_sendmsg: %s",zmq_strerror(errno));
		zmq_msg_close(&channelEnvlp) && LOG_WARN("zmq_msg_close: %s",zmq_strerror(errno));

		// mandatory meta fields
		msg->setMeta("publisher", _uuid);
		msg->setMeta("proc", procUUID);

		// all our meta information
		map<string, string>::const_iterator metaIter;
		for (metaIter = msg->getMeta().begin(); metaIter != msg->getMeta().end(); metaIter++) {

			// string length of key + value + two null bytes as string delimiters
			size_t metaSize = (metaIter->first).length() + (metaIter->second).length() + 2;
			zmq_msg_t metaMsg;
			ZMQ_PREPARE(metaMsg, metaSize);

			char* writePtr = (char*)zmq_msg_data(&metaMsg);

			memcpy(writePtr, (metaIter->first).data(), (metaIter->first).length());
			// indexes start at zero, so length is the byte after the string
			((char*)zmq_msg_data(&metaMsg))[(metaIter->first).length()] = '\0';
			assert(strlen((char*)zmq_msg_data(&metaMsg)) == (metaIter->first).length());
			assert(strlen(writePtr) == (metaIter->first).length()); // just to be sure

			// increment write pointer
			writePtr += (metaIter->first).length() + 1;

			memcpy(writePtr,
			       (metaIter->second).data(),
			       (metaIter->second).length());
			// first string + null byte + second string
			((char*)zmq_msg_data(&metaMsg))[(metaIter->first).length() + 1 + (metaIter->second).length()] = '\0';
			assert(strlen(writePtr) == (metaIter->second).length());

			zmq_sendmsg((*nodeIter)->_pubSocket, &metaMsg, ZMQ_SNDMORE) >= 0 || LOG_WARN("zmq_sendmsg: %s",zmq_strerror(errno));
			zmq_msg_close(&metaMsg) && LOG_WARN("zmq_msg_close: %s",zmq_strerror(errno));
		}

		// data as the second part of a multipart message
		zmq_msg_t publication;
		ZMQ_PREPARE_DATA(publication, msg->getData().data(), msg->getData().size());
		LOG_WARN("Sending %d bytes on %s", msg->getData().size(), _channelName.c_str());
		zmq_sendmsg((*nodeIter)->_pubSocket, &publication, 0) >= 0 || LOG_WARN("zmq_sendmsg: %s",zmq_strerror(errno));
		zmq_msg_close(&publication) && LOG_WARN("zmq_msg_close: %s",zmq_strerror(errno));

		(*nodeIter)->_mutex.unlock();
	}
	_mutex.unlock();
}


}